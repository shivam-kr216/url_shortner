<?php  
	if(isset($_GET['id'])){
		echo "<script>
			alert('There are no fields to generate a report');
			window.location.href='http://www.geeksforgeeks.org';
			</script>";
		//header('Location: https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js');
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>short_url</title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
</head>
<body>
	<div class="container-fluid">
        <div class="jumbotron" style="border: none; outline: none;">
            <h1 style="font-size: 4.5rem; padding-bottom: 12px;">uc</h1>
        </div>
	</div>
	
		<input type="text" name="url" style="padding: 5px;" placeholder="Enter URL">
		<input type="submit" value="Short Your Url" style="padding: 5px; font-weight: 800;"><br>
		<p class="errors"></p>

	<script type="text/javascript">
		$(document).ready(function(){
			$('input[type="submit"]').click(function(e){
				e.preventDefault();

				$('.errors').html('');
				var url = $('input[name="url"]').val();

				if(url.length == 0){
					$('.errors').html('Whoops! Please enter a URL!');
					return false;
				}

				$.post('/php/BackEnd/includes/process.php', {
					url: url
				}, function(data, textStatus, xhr) {
					console.log(textStatus);
					console.log(data);
					var od = data;
					data = 'http://localhost/php/BackEnd/index.php?id='+data;
					$('.errors').html('<a href="' + data + '" target="_blank">short/' + od + '</a>')
				});
			});
		});
	</script>

	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"
        integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN"
        crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"
        integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q"
        crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"
        integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl"
        crossorigin="anonymous"></script>


</body>
</html>













<?php  
	if(isset($_GET['id'])){
		include $_SERVER['DOCUMENT_ROOT'] . '/php/BackEnd/includes/functions.php';
		$id  = $_GET['id'];
		$url = getUrlLocation($id);
		header('Location: ' . $url);
	}
?>

<!DOCTYPE html>
<html>
<head>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	<title>URL Shortener</title>
</head>
<body>
	<input type="text" name="url">
	<input type="submit" value="Shorten My URL!"><br>
	<p class="errors"></p>

	<script type="text/javascript">
		$(document).ready(function(){
			$('input[type="submit"]').click(function(e){
				e.preventDefault();

				$('.errors').html('');
				var url = $('input[name="url"]').val();

				if(url.length == 0){
					$('.errors').html('Whoops! Please enter a URL!');
					return false;
				}

				$.post('/php/BackEnd/includes/process.php', {
					url: url
				}, function(data, textStatus, xhr) {
					var od = data;
					data = 'http://localhost/php/BackEnd/index.php?id='+data;
					$('.errors').html('<a href="' + data + '" target="_blank">sho.rt/' + od + '</a>')
				});
			});
		});
	</script>
</body>
</html>